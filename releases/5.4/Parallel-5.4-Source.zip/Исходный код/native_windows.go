//go:build windows

package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io/fs"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"time"

	"github.com/wailsapp/wails/v2"
	"github.com/wailsapp/wails/v2/pkg/options"
	"github.com/wailsapp/wails/v2/pkg/options/assetserver"
	"github.com/wailsapp/wails/v2/pkg/options/windows"
	wruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

func desktopSupported() bool { return true }
func runDesktop(dir string, initialPaths ...string) error {
	if err := ensureWebView2(); err != nil {
		return err
	}
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	// An older HTTP build must release the shared database before native mode starts.
	if raw, err := os.ReadFile(filepath.Join(dir, "session.json")); err == nil {
		var old Session
		if json.Unmarshal(raw, &old) == nil && strings.HasPrefix(old.URL, "http://127.0.0.1:") {
			req, _ := http.NewRequest("GET", strings.Split(old.URL, "/?")[0]+"/api/ping", nil)
			req.Header.Set("X-App-Token", old.Token)
			client := &http.Client{Timeout: time.Second}
			if res, err := client.Do(req); err == nil {
				res.Body.Close()
				if res.StatusCode == 200 {
					return fmt.Errorf("закройте предыдущую программу через «Сохранить и выйти», затем снова запустите Параллель")
				}
			}
		}
	}
	bridge, err := newDesktopBridge(dir, true)
	if err != nil {
		return err
	}
	assets, err := fs.Sub(bundled, "ui")
	if err != nil {
		return err
	}
	logfile, err := os.OpenFile(filepath.Join(dir, "application.log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	defer logfile.Close()
	log.SetOutput(logfile)
	var ctx context.Context
	var closing atomic.Bool
	bridge.wakeProjects = func() {
		wruntime.WindowUnminimise(ctx)
		wruntime.WindowShow(ctx)
		wruntime.EventsEmit(ctx, "parallel:project-request")
	}
	bridge.quit = func() { closing.Store(true); wruntime.Quit(ctx) }
	bridge.openFile = func(kind string) (string, error) {
		filters := []wruntime.FileFilter{{DisplayName: "Расписание Параллель", Pattern: "*.parallel"}, {DisplayName: "Резервные копии JSON", Pattern: "*.json"}}
		if kind == "table" {
			filters = []wruntime.FileFilter{{DisplayName: "Таблицы Excel", Pattern: "*.xlsx"}, {DisplayName: "Текстовые таблицы CSV / TSV", Pattern: "*.csv;*.tsv"}}
		}
		return wruntime.OpenFileDialog(ctx, wruntime.OpenDialogOptions{Title: "Открыть файл", Filters: filters})
	}
	bridge.savePath = func(name, kind string) (string, error) {
		pattern, label := "*.parallel", "Расписание Параллель"
		if kind == "xlsx" {
			pattern, label = "*.xlsx", "Таблица Excel"
		}
		if kind == "csv" {
			pattern, label = "*.csv", "Таблица CSV"
		}
		return wruntime.SaveFileDialog(ctx, wruntime.SaveDialogOptions{Title: "Сохранить файл", DefaultFilename: name, Filters: []wruntime.FileFilter{{DisplayName: label, Pattern: pattern}}})
	}
	bridge.saveFile = func(name string, raw []byte) (bool, error) {
		ext := strings.ToLower(filepath.Ext(name))
		pattern := "*" + ext
		dest, err := wruntime.SaveFileDialog(ctx, wruntime.SaveDialogOptions{Title: "Сохранить файл", DefaultFilename: name, Filters: []wruntime.FileFilter{{DisplayName: strings.ToUpper(strings.TrimPrefix(ext, ".")) + " файл", Pattern: pattern}}})
		if err != nil || dest == "" {
			return false, err
		}
		if err := atomicWrite(dest, raw); err != nil {
			return false, err
		}
		return true, nil
	}
	messages := windows.DefaultMessages()
	messages.MissingRequirements = "Параллель: системный компонент"
	messages.InstallationRequired = "Для окна приложения нужен Microsoft Edge WebView2 Runtime. Установщик Microsoft загрузит его из интернета."
	messages.PressOKToInstall = " Нажмите OK для установки. Ваш браузер не запускается."
	messages.ContactAdmin = "Установите Microsoft Edge WebView2 Runtime через установщик Параллель и повторите запуск."
	messages.Webview2NotInstalled = "WebView2 не установлен. Установите Microsoft Edge WebView2 Runtime и повторите запуск."
	log.Printf("Starting native desktop %s", version)
	return wails.Run(&options.App{
		Title: "Параллель · Расписание школы", Width: 1440, Height: 900, MinWidth: 1024, MinHeight: 640,
		WindowStartState: options.Maximised, BackgroundColour: options.NewRGB(244, 246, 249),
		EnableFraudulentWebsiteDetection: true,
		AssetServer:                      &assetserver.Options{Assets: desktopAssets{assets}, Middleware: documentHeaders}, Bind: []interface{}{bridge},
		OnStartup: func(c context.Context) {
			ctx = c
			// Wails has acquired its single-instance lock before this callback.
			// A forwarded second launch must never restore over the active recovery.
			bridge.initialiseErr = bridge.initialiseStore()
			if bridge.initialiseErr == nil && len(initialPaths) > 0 && initialPaths[0] != "" {
				bridge.queueProject(initialPaths[0])
			}
			close(bridge.initialised)
			if bridge.initialiseErr != nil {
				log.Printf("Native startup failed: %v", bridge.initialiseErr)
				wruntime.MessageDialog(c, wruntime.MessageDialogOptions{Type: wruntime.ErrorDialog, Title: "Не удалось открыть расписание", Message: bridge.initialiseErr.Error()})
				closing.Store(true)
				wruntime.Quit(c)
			}
		},
		OnBeforeClose: func(c context.Context) bool {
			if closing.Load() || !bridge.ready.Load() {
				return false
			}
			wruntime.EventsEmit(c, "parallel:close-request")
			return true
		},
		SingleInstanceLock: &options.SingleInstanceLock{UniqueId: appID, OnSecondInstanceLaunch: func(data options.SecondInstanceData) {
			<-bridge.initialised
			if bridge.initialiseErr != nil {
				return
			}
			if ctx != nil {
				for _, arg := range data.Args {
					if strings.EqualFold(filepath.Ext(arg), ".parallel") {
						path := arg
						if !filepath.IsAbs(path) {
							path = filepath.Join(data.WorkingDirectory, path)
						}
						bridge.queueProject(path)
						break
					}
				}
				if bridge.ready.Load() {
					bridge.wakeProjects()
				}
			}
		}},
		Windows: &windows.Options{WebviewUserDataPath: filepath.Join(dir, "WebView2"), Messages: messages, Theme: windows.Light, WindowClassName: "ParallelSchoolDesktop", ResizeDebounceMS: 16},
	})
}
